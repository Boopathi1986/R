#!/usr/bin/gnuplot
reset
set encoding utf8
set term png
set output "ABGDMEMcontact.png"
#set output "ABGDMEMcontact2.png"
set mxtics 10 
set mytics 10
set cbtics font "Times-Roman,18" offset -1
set xtics font "Times-Roman,20"
set ytics font "Times-Roman,20" offset 1
set title "A{/symbol b}_{1-42}-gD-Mem" font "Times-Roman,40"
set xrange [0.98:426]
set yrange [0.98:426]
#set xrange [260:426]
#set yrange [260:426]
set xlabel "Residue number" font "Times-Roman,20"
set ylabel "Residue number" font "Times-Roman,20"
set pm3d map
set palette color
set pal maxcolor 128
set cbrange [0:100] 
#set palette model RGB defined (0 "dark-blue", 10 "web-blue", 15 "cyan", 40 "green", 60 "yellow", 80 "orange", 100 "red") 
set palette model RGB defined (0 "white",5 "light-blue", 10 "web-blue", 20 "midnight-blue", 30 "navy", 40 "green", 50 "greenyellow", 60 "orange", 70 "dark-orange", 80 "orange-red", 100 "red")
set autoscale fix
set xtics in
set ytics in
splot "abgdmemcontact.dat" u 1:2:3

