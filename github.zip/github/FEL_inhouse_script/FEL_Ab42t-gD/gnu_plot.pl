#!/usr/bin/gnuplot
        reset
        set encoding utf8
	set term png
        set output "FEL_Ab42gDwomMem.png"
	set yrange [15:18]
	set ytics font "Time-Roman,20"
        set title "A{/symbol b}_{1-42}-gD" font "Times-Roman,40"
	set ylabel " Rg (\305)"    font "Time-Roman,20" # offset -1 # textcolor rgb "blue" 
        set ylabel offset -2,0
	set xlabel offset 0,-1
######################### X tics ###########################
        set lmargin 6
	set xrange [.0:12.0]
	set xtics font "Time-Roman,20" 
	set xlabel " RMSD  (\305)" font "Time-Roman,20" #textcolor rgb "blue"
	
######################  set color ############
        set palette rgbformulae 33,13,10
        set cbrange[0:8]
	set cbtics font "Time-Roman,16"
	set cblabel "\n Free energy (kcal/mol)" font "Time-Roman,20" offset -1
	#set format cb "% g"
	#set palette defined (0 "brown4", 0.1 "dark-red", 0.5 "red", 1 "orange", 2 "yellow",3 "greenyellow", 4 "web-green", 5 "web-blue", 6 "navy", 7 "white")

	#set palette defined (0 "brown", 0.3 "orangered4", 0.6 "red", 2 "yellow", 3 "cyan", 4 "dark-blue", 4.5 "medium-blue", 5 "navy", 8 "white")
       	
	#	set palette defined (0 "black", 0.3 "brown4", 0.5 "dark-violet", 1 "dark-blue", 1.5 "navy", 2 "web-blue", 2.5 "cyan", 3 "yellow", 4 "greenyellow", 4.5 "web-green", 5 "orange-red", 6 "red", 7 "light-red", 7.8 "dark-red",  8 "white")

	#	set palette defined (0 "black", 0.5 "light-red", 0.8 "orange-red", 1.5 "orange", 2 "yellow", 2.5 "greenyellow", 3.5 "green", 4 "cyan", 5 "blue", 6 "midnight-blue", 7 "navy", 8 "white")


set palette defined (0 "black", 0.2 "black", 0.3 "brown", 0.4 "brown4",0.5 "light-magenta", 0.8 "dark-magenta", 1 "web-blue", 1.1 "medium-blue", 1.3 "navy", 1.5 "cyan", 2 "web-green", 2.5 "greenyellow", 3 "yellow", 4 "orange", 5 "light-red", 6 "red", 7.5 "orange-red", 7.6 "white",  8 "white")	
######################################################
        set pm3d map
	set surface
        splot 'ABGDDG.dat' u 1:2:3 notitle
############
