#!/usr/bin/perl
 use POSIX;
$file="abgdwomrmsdrg.dat";
$nx=200;
$ny=200;
$fileout="pm3d_${nx}_${ny}.dat";

open (IN,"<$file");
$xmax=0;$xmin=1000;
$ymax=0;$ymin=1000;
while (<IN>){
        chomp;
        my @line=split;
        if ($line[0] > $xmax ){$xmax =$line[0];}
        if ($line[0] < $xmin ){$xmin =$line[0];}
        if ($line[1] > $ymax ){$ymax =$line[1];}
        if ($line[1] < $ymin ){$ymin =$line[1];}
}
close IN;
$dx=($xmax-$xmin)/$nx;
$dy=($ymax-$ymin)/$ny;
print "
xmax:          $xmax
xmin:          $xmin
dx:        $dx
        
ymax:           $ymax
ymin:           $ymin
dy:         $dy
";
#################################
for (my $x=0;$x<$nx;$x++){
	for (my $y=0;$y<$ny;$y++){
	$array[$x][$y]=0;
	}
}
open (IN,"<$file");
while (<IN>){
	chomp;my @line=split; $array[floor(($line[0]-$xmin)/$dx)][floor(($line[1]-$ymin)/$dy)]++;
	#chomp;my @line=split; $array[floor($line[0]/$dx)][floor($line[1]/$dy)]++;
	}
close IN;
open (OUT,">$fileout");
for (my $x=0;$x<$nx;$x++){
	for (my $y=0;$y<$ny;$y++){
	printf OUT ("%10.8f %10.8f %5s\n", $xmin+$x*$dx, $ymin+$y*$dy, $array[$x][$y]);
	}
	print OUT "\n";
}
close OUT;
